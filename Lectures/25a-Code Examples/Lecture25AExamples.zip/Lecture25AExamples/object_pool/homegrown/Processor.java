public class Processor extends Thread {

  private int   id;
  private Prime p;

  public Processor(int id) {
    super();
    this.id = id;
  }

  public int id() {
    return id;
  }

  public Prime getPrime() {
    return p;
  }

  public synchronized void setPrime(Prime p) {
    this.p = p;
    notify();
  }

  public synchronized void run() {
    try {
      while (p == null) {
        wait();
      }
    } catch (Exception e) {
    }
    p.process();
  }

}
