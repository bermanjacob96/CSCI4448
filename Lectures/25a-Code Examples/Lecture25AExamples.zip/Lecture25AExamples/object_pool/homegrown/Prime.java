public class Prime {

  public int  lower_bound;
  public int  upper_bound;
  public int  total;

  public Prime(int lower, int upper) {
    lower_bound = lower;
    upper_bound = upper;
  }

  private boolean isPrime(int number) {
    if (number <= 1) return false;

    for (int i = 2; i <= Math.sqrt(number); i++) {
      if (number % i == 0) {
        return false;
      }
    }

    return true;

  }

  public int calculate() {
    for (int i = lower_bound; i <= upper_bound; i++) {
      if (isPrime(i)) {
        total++;
      }
    }

    return total;
  }
  
  public void process() {
    calculate();
    System.out.println("Prime<" + lower_bound + "," + upper_bound + ">: Done!");
  }

  public static void main(String[] args) {
    Prime p = new Prime(1, 20000000);
    long start = System.nanoTime();
    p.process();
    long end = System.nanoTime();
    double total_time = (end - start) / 1.0e9;
    System.out.printf("Number of primes between %d and %d is %d\n", p.lower_bound, p.upper_bound, p.total);
    System.out.println("Calculated in : " + total_time + " seconds.");
  }


}
