import java.util.concurrent.ArrayBlockingQueue;

public class Producer extends Thread {

  private ArrayBlockingQueue<Processor> queue;
  private Consumer c;
  private boolean notified;
  private int partitions;

  public Producer(int partitions) {
    queue = new ArrayBlockingQueue<Processor>(4);
    this.partitions = partitions;
  }

  public Processor take() {
    return queue.poll();
  }

  public void setConsumer(Consumer c) {
    this.c = c;
  }

  public void run() {
    ThreadPool t = ThreadPool.getInstance();

    int number = 20000000;

    int chunks = number / partitions;

    for (int i = 0; i < partitions; i++) {
      int lower = (i * chunks) + 1;
      int upper = (i == partitions - 1) ?  number : lower + chunks - 1;
      Prime p = new Prime(lower, upper);
      Processor proc = t.getProcessor();
      proc.setPrime(p);
      try {
        queue.put(proc);
        System.out.println("Producer: Added <" + lower + "," + upper + ">");
        if (!notified) {
          c.go();
          notified = true;
        }
      } catch (Exception e) {
      }
    }
    System.out.println("Producer: Finished!");
  }
}
