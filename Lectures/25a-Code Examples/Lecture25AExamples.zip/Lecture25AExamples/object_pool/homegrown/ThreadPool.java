import java.util.concurrent.ArrayBlockingQueue;

public class ThreadPool {

  private static ThreadPool pool;

  private ArrayBlockingQueue<Processor> threads;

  private ThreadPool() {
    threads = new ArrayBlockingQueue<Processor>(4);

    Processor p0 = new Processor(0);
    Processor p1 = new Processor(1);
    Processor p2 = new Processor(2);
    Processor p3 = new Processor(3);

    p0.setDaemon(true);
    p1.setDaemon(true);
    p2.setDaemon(true);
    p3.setDaemon(true);

    p0.start();
    p1.start();
    p2.start();
    p3.start();

    try {
      threads.put(p0);
      threads.put(p1);
      threads.put(p2);
      threads.put(p3);
    } catch (Exception e) {
    }

  }

  public static synchronized ThreadPool getInstance() {
    if (pool == null) {
      pool = new ThreadPool();
    }
    return pool;
  }

  public Processor getProcessor() {
    try {
      return threads.take();
    } catch (Exception e) {
    }
    return null;
  }

  public void returnProcessor(Processor p) {
    try {
      threads.put(p);
    } catch (Exception e) {
    }
  }

}
