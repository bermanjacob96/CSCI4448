public class Consumer extends Thread {

  private int total;

  private Producer producer;

  public Consumer(Producer p) {
    this.producer = p;
  }

  public synchronized void go() {
    notifyAll();
  }

  public void printMessage(String message, Processor p) {
    System.out.print("Consumer:");
    System.out.print(message + ": <");
    System.out.print("" + p.getPrime().lower_bound);
    System.out.print(",");
    System.out.print("" + p.getPrime().upper_bound);
    System.out.println(">");
  }

  public synchronized void run() {

    ThreadPool t = ThreadPool.getInstance();

    try {
      wait();
    } catch (Exception e) {
    }

    long start = System.nanoTime();

    Processor p = producer.take();
    printMessage("Received", p);
    while (p != null) {
      try {
        p.join();
        printMessage("Joined", p);
      } catch (Exception e) {
      }

      Processor new_p = new Processor(p.id());
      new_p.setDaemon(true);
      new_p.start();
      t.returnProcessor(new_p);

      total += p.getPrime().total;
      p = producer.take();
      if (p != null) {
        printMessage("Received", p);
      }
    }

    long end = System.nanoTime();

    double total_time = (end - start) / 1.0e9;

    System.out.printf("Number of primes is %d\n", total);
    System.out.println("Calculated in : " +  total_time + " seconds.");
  }
}
