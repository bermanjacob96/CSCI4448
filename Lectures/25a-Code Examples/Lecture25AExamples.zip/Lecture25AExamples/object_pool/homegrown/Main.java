public class Main {

  public static void main(String[] args) {
    Producer   p = new Producer(Integer.parseInt(args[0]));
    Consumer   c = new Consumer(p);
    p.setConsumer(c);
    p.start();
    c.start();
    try {
      c.join();
    } catch (Exception e) {
    }
    System.out.println("All done!");
  }

}
