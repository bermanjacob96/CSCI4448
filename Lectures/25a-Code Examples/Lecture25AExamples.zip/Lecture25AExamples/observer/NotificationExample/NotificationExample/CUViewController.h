//
//  CUViewController.h
//  NotificationExample
//
//  Created by Ken Anderson on 11/19/12.
//  Copyright (c) 2012 University of Colorado. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CUViewController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *longLabel;

@end
