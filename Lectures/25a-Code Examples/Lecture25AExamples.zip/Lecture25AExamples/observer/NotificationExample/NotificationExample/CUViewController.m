//
//  CUViewController.m
//  NotificationExample
//
//  Created by Ken Anderson on 11/19/12.
//  Copyright (c) 2012 University of Colorado. All rights reserved.
//

#import "CUViewController.h"

@interface CUViewController ()

- (void)orientationChanged:(NSNotification *)notification;

@end

@implementation CUViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [[UIDevice currentDevice] beginGeneratingDeviceOrientationNotifications];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(orientationChanged:)
                                                 name:UIDeviceOrientationDidChangeNotification
                                               object:nil];

}

- (void)orientationChanged:(NSNotification *)notification {
    UIDeviceOrientation deviceOrientation = [UIDevice currentDevice].orientation;
    if (UIDeviceOrientationIsLandscape(deviceOrientation)) {
        self.longLabel.text = @"This is a really, really, really, really, really, long label.";
    } else if (UIDeviceOrientationIsPortrait(deviceOrientation)) {
        self.longLabel.text = @"This is a really, really, long label.";
    }
}


@end
